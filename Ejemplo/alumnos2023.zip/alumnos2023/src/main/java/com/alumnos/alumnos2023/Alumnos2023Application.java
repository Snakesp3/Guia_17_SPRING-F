package com.alumnos.alumnos2023;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Alumnos2023Application {

	public static void main(String[] args) {
		SpringApplication.run(Alumnos2023Application.class, args);
	}

}
