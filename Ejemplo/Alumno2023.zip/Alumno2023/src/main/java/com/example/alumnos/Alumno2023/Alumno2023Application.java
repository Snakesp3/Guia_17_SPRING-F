package com.example.alumnos.Alumno2023;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Alumno2023Application {

	public static void main(String[] args) {
		SpringApplication.run(Alumno2023Application.class, args);
	}

}
